# Config file for Blum AutoFarm

CLICK_INTERVAL = 3  # Интервал кликов в секундах
CLOUD_ACCOUNTS_URL = "https://example.com/blum_accounts.json"  # URL с аккаунтами
